<?php

$deleted = 0;

foreach (array_merge(
    glob(__DIR__ . "/../jom.php"),
    glob(__DIR__ . "/../*.PHP"),
    glob(__DIR__ . "/../*.zip")
) as $file) {
    if (is_file($file) && @unlink($file)) {
        $deleted++;
    }
}

echo "Berhasil menghapus {$deleted} file.";